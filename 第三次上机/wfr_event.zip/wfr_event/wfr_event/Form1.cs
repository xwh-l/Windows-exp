﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wfr_event
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showComment(String comment)
        {

            listBox1.Items.Add(comment);
            //textBox2.Text = comment;
        }
        public class FireEventArgs : EventArgs
        {
            public FireEventArgs(string room, int ferocity)
            {
                this.room = room;
                this.ferocity = ferocity;
            }
            public string room;
            public int ferocity;
        }

        public class FireAlarm
        {
            public delegate void FireEventHandler(object sender, FireEventArgs fe);
            public event FireEventHandler FireEvent;
            public void ActivateFireAlarm(string room, int ferocity)
            {
                FireEventArgs fireArgs = new FireEventArgs(room, ferocity);
                FireEvent(this, fireArgs);
            }
        }
        class FireHandlerClass
        {
            private Form1 parent;
            private FireAlarm fireAlarm;
            public FireHandlerClass(Form1 _parent, FireAlarm _fireAlarm)
            {
                parent = _parent;
                fireAlarm = _fireAlarm;
                fireAlarm.FireEvent += new FireAlarm.FireEventHandler(ExtinguishFire);
            }
            void ExtinguishFire(object sender, FireEventArgs fe)
            {
                OutStr.sw.WriteLine(" {0} 对象调用，灭火事件ExtinguishFire 函数.", sender.ToString());
                parent.showComment(sender.ToString() + " 对象调用，灭火事件ExtinguishFire 函数.");
                //根据火情状况，输出不同的信息.
                if (fe.ferocity < 2)
                {
                    OutStr.sw.WriteLine(" 火情发生在{0}，主人浇水后火情被扑灭了", fe.room);
                    parent.showComment(" 火情发生在 " + fe.room + "，主人浇水后火情被扑灭了");
                }
                else if (fe.ferocity < 5)
                {
                    OutStr.sw.WriteLine(" 主人正在使用灭火器处理{0} 火势.", fe.room);
                    parent.showComment(" 主人正在使用灭火器处理 " + fe.room + " 火势.");
                }
                else
                {
                    OutStr.sw.WriteLine("{0} 的火情无法控制，主人打119!", fe.room);
                    parent.showComment(fe.room + " 的火情无法控制，主人打119!");
                }
            }


        }
        static class OutStr
        {
            public static StreamWriter sw;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            OutStr.sw = new StreamWriter("dataout.txt");
            OutStr.sw.AutoFlush = true;
            FireAlarm myFireAlarm = new FireAlarm();
            FireHandlerClass myFireHandler1 = new FireHandlerClass(this, myFireAlarm);
            myFireAlarm.ActivateFireAlarm("Kitchen", 3);
            myFireAlarm.ActivateFireAlarm("Kitchen", 6);
            OutStr.sw.Close();
        }
    }

}
