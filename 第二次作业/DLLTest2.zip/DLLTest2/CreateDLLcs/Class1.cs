﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateDLLcs
{
    public class Class1
    {
        public int add(int x, int y)
        {
            return x + y;
        }
    }
}
