﻿using System;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using CreateDLLcs;


namespace CSharpCallDLL2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        class DllTest
        {
            [DllImport(@"../../../Release/CreateDLL.dll", EntryPoint = "test01", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = false, CallingConvention = CallingConvention.StdCall)]
            public static extern int test01(int a);

            [DllImport(@"../../../Release/CreateDLL.dll", EntryPoint = "test02", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = false, CallingConvention = CallingConvention.StdCall)]
            public static extern int test02(int a, int b);
        }

        //调用c++dll
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox2.Text == "")
            {
                MessageBox.Show("请输入求阶乘的数字！");
            }
            else
            {
                int r1 = DllTest.test01(int.Parse(textBox2.Text));
                textBox1.Text = r1.ToString();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox3.Text);
            int b = int.Parse(textBox4.Text);
            int res = DllTest.test02(a, b);
            textBox5.Text = res.ToString();
        }

        
        //调用C#dll
        private void button3_Click(object sender, EventArgs e)
        {
            int a = int.Parse(textBox3.Text);
            int b = int.Parse(textBox4.Text);
            Class1 cl = new Class1();
            int res = cl.add(a, b);
            textBox5.Text = res.ToString();
        }
    }
}
