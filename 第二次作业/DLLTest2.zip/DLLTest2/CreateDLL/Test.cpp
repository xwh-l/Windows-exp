#include"Test.h"
#include"pch.h"
int _stdcall test01(int a)
{
	if (a < 0)  return -1;
	else if (a > 31)return 0;
	else if (a == 0)return 1;
	else return(a * test01(a - 1));
}
int _stdcall test02(int a, int b)
{
	if (a >= b)return (a - b);
	else return (b - a);
}